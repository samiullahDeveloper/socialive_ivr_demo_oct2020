package com.sociallive.scripts;

import java.sql.Connection;
import java.util.Map;

import org.apache.log4j.Logger;
import org.asteriskjava.fastagi.AgiChannel;
import org.asteriskjava.fastagi.AgiException;
import org.asteriskjava.fastagi.AgiRequest;

import com.agiserver.helper.DBConnectionManager;
import com.agiserver.helper.DBHelper;
import com.agiserver.helper.common.AbstractBaseAgiScript;
import com.sociallive.common.Helper;

public class CheckSub extends AbstractBaseAgiScript {
	
	private static final Logger	logger	= Logger.getLogger(CheckSub.class);

	@Override
	public void service(AgiRequest request, AgiChannel channel) throws AgiException {
		Connection	conn		= null;
		String		cellno		= "";
		String		uniqueId	= "";
		String		logTag		= "";
		try {
			conn = DBConnectionManager.getInstance().getConnection();
			channel.setVariable("IS_SUB", "NO");
			cellno = channel.getVariable("DB_CLI");
			cellno = "0" + Helper.formatCellNumber(cellno);
			uniqueId = channel.getVariable("DB_USER_ID");
			logTag	= "DB_CLI : " + cellno + " DB_USER_ID: " + uniqueId + " : ";
			logger.info(logTag + " AGI_start");
			String query = "SELECT * from subscribers  WHERE `cellno`=? and `is_active`=?";
			Map<String, Object> cellnoHashMap = null;
			cellnoHashMap = DBHelper.getInstance().firstRow(query, conn, new Object[] { cellno, true });
			if (!(cellnoHashMap == null)) {
				logger.info(logTag + "Subscriber record Found" + cellnoHashMap);
				String lang = (String) cellnoHashMap.get("lang");
				channel.setVariable("IS_SUB", "YES");
				channel.setVariable("LANG", lang);
			}
			else {
				logger.info(logTag + "not a subscriber");
			}
		} catch (Exception e) {
			logger.error(logTag + "Exception", e);
		} finally {
			logger.info(logTag + "AGI_end");
		}
	}
}
