package com.sociallive.scripts;

import java.sql.Connection;
import org.apache.log4j.Logger;
import org.asteriskjava.fastagi.AgiChannel;
import org.asteriskjava.fastagi.AgiException;
import org.asteriskjava.fastagi.AgiRequest;

import com.agiserver.helper.DBConnectionManager;
import com.agiserver.helper.DBHelper;
import com.agiserver.helper.common.AbstractBaseAgiScript;
import com.sociallive.common.Helper;

public class SubConfirm extends AbstractBaseAgiScript {
	private static final Logger	logger	= Logger.getLogger(SubConfirm.class);

	@Override
	public void service(AgiRequest request, AgiChannel channel) throws AgiException {
		Connection	conn		= null;
		String		cellno		= "";
		String		uniqueId	= "";
		String		logTag		= "";
		try {
			conn = DBConnectionManager.getInstance().getConnection();
			channel.setVariable("IS_SUB", "NO");
			cellno = channel.getVariable("DB_CLI");
			cellno = "0" + Helper.formatCellNumber(cellno);
			uniqueId = channel.getVariable("DB_USER_ID");
			logTag	= "DB_CLI : " + cellno + " DB_USER_ID: " + uniqueId + " : ";
			logger.info(logTag + "AGI_start");
			String	query = "INSERT INTO subscribers (cellno, lang, is_active, sub_dt) values (?, ?, ?, NOW())";
			DBHelper.getInstance().insert(query, conn, new Object[] { cellno, "urdu", true});
			
				logger.info(logTag + "Subscription confirm");
				channel.setVariable("IS_SUB", "YES");
		} catch (Exception e) {
			logger.error(logTag + "Exception", e);
		} finally {
			logger.info(logTag + "AGI_end");
		}
	}
}
