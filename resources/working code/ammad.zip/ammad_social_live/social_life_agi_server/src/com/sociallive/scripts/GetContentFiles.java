package com.sociallive.scripts;

import java.sql.Connection;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.asteriskjava.fastagi.AgiChannel;
import org.asteriskjava.fastagi.AgiException;
import org.asteriskjava.fastagi.AgiRequest;
import com.agiserver.helper.DBConnectionManager;
import com.agiserver.helper.DBHelper;
import com.agiserver.helper.common.AbstractBaseAgiScript;
import com.sociallive.common.Helper;

public class GetContentFiles extends AbstractBaseAgiScript {
	private static final Logger	logger	= Logger.getLogger(GetContentFiles.class);
	
	@Override
	public void service(AgiRequest request, AgiChannel channel) throws AgiException {
		Connection	conn		= null;
		String		cellno		= "";
		String		uniqueId	= "";
		String		logTag		= "";
		try {
			conn = DBConnectionManager.getInstance().getConnection();
			channel.setVariable("IS_SUB", "NO");
			cellno = channel.getVariable("DB_CLI");
			cellno = "0" + Helper.formatCellNumber(cellno);
			uniqueId = channel.getVariable("DB_USER_ID");
			logTag	= "DB_CLI : " + cellno + " DB_USER_ID: " + uniqueId + " : ";
			logger.info(logTag + "AGI_start");
			String category = channel.getVariable("CATEGORY_KEY");
			logger.info(logTag + "category : " + category);
			String query = "SELECT filename FROM content_files";
			List<Map<String, Object>> filesList = DBHelper.getInstance().query(query, conn, new Object[] { });
			if (!(filesList == null)) {
				Integer	index = 1;
				for(Map<String, Object> file : filesList) {
					String	fileName	= (String)	file.get("filename");
					channel.setVariable("CONTENT_FILE_NAME_" + index.toString(), fileName);
					index++;
				}
				Integer	totalFiles	= filesList.size();
				channel.setVariable("TOTAL_FILES", totalFiles.toString());
				logger.info(logTag + "total file : " + totalFiles);
			}
			else {
				channel.setVariable("TOTAL_FILES", "0");
				logger.info(logTag + "no file found");
			}
		} catch (Exception e) {
			logger.error(logTag + "Exception", e);
		} finally {
			logger.info(logTag + " AGI_end");
		}
	}
}
