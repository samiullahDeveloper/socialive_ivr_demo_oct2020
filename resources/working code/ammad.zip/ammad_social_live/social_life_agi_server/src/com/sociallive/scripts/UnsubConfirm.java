package com.sociallive.scripts;

import java.sql.Connection;
import org.apache.log4j.Logger;
import org.asteriskjava.fastagi.AgiChannel;
import org.asteriskjava.fastagi.AgiException;
import org.asteriskjava.fastagi.AgiRequest;

import com.agiserver.helper.DBConnectionManager;
import com.agiserver.helper.DBHelper;
import com.agiserver.helper.common.AbstractBaseAgiScript;
import com.sociallive.common.Helper;

public class UnsubConfirm  extends AbstractBaseAgiScript {
	private static final Logger	logger	= Logger.getLogger(UnsubConfirm.class);

	@Override
	public void service(AgiRequest request, AgiChannel channel) throws AgiException {
		Connection	conn		= null;
		String		cellno		= "";
		String		uniqueId	= "";
		String		logTag		= "";
		try {
			channel.setVariable("IS_UNSUB", "NO");
			conn = DBConnectionManager.getInstance().getConnection();
			channel.setVariable("IS_SUB", "NO");
			cellno = channel.getVariable("DB_CLI");
			cellno = "0" + Helper.formatCellNumber(cellno);
			uniqueId = channel.getVariable("DB_USER_ID");
			logTag	= "DB_CLI : " + cellno + " DB_USER_ID: " + uniqueId + " : ";
			logger.info(logTag + "AGI_start");
			String query = "DELETE from subscribers  WHERE `cellno`=? and `is_active`=?";
			DBHelper.getInstance().executeDml(query, conn, new Object[] {cellno, true });
			channel.setVariable("IS_UNSUB", "YES");
			logger.info(logTag + "unsub confirm");

		} catch (Exception e) {
			logger.error(logTag + "Exception", e);
		} finally {
			logger.info(logTag + " AGI_end");
		}
	}
}
