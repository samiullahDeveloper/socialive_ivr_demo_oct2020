-- MySQL dump 10.13  Distrib 5.7.28, for Linux (x86_64)
--
-- Host: localhost    Database: social_live
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cellno` varchar(12) DEFAULT NULL,
  `dt` datetime DEFAULT NULL,
  `activity_type` varchar(170) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `dtmf` varchar(2) DEFAULT NULL,
  `context` varchar(170) DEFAULT NULL,
  `unique_id` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity`
--

LOCK TABLES `activity` WRITE;
/*!40000 ALTER TABLE `activity` DISABLE KEYS */;
INSERT INTO `activity` VALUES (1,'3216020287','2020-01-20 19:04:08','welcome',4,'h','SOCIAL_LIVE_CHECK_SUB','1579529044.4'),(2,'3216020287','2020-01-20 19:18:30','welcome',12,'s','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6'),(3,'3216020287','2020-01-20 19:18:30','main_menu',10,'2','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6'),(4,'3216020287','2020-01-20 19:18:31','content_1',2,'s','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6'),(5,'3216020287','2020-01-20 19:18:31','content_traversal_menu',1,'1','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6'),(6,'3216020287','2020-01-20 19:18:31','first_article',5,'1','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6'),(7,'3216020287','2020-01-20 19:18:31','content_1',3,'s','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6'),(8,'3216020287','2020-01-20 19:18:31','content_traversal_menu',2,'2','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6'),(9,'3216020287','2020-01-20 19:18:31','content_2',2,'s','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6'),(10,'3216020287','2020-01-20 19:18:31','content_traversal_menu',2,'3','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6'),(11,'3216020287','2020-01-20 19:18:31','content_2',2,'0','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6'),(12,'3216020287','2020-01-20 19:18:31','main_menu',7,'5','SOCIAL_LIVE_PLAY_CONTENT','1579529862.6');
/*!40000 ALTER TABLE `activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_files`
--

DROP TABLE IF EXISTS `content_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(50) NOT NULL,
  `is_active` bit(1) NOT NULL,
  `dt_modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_files`
--

LOCK TABLES `content_files` WRITE;
/*!40000 ALTER TABLE `content_files` DISABLE KEYS */;
INSERT INTO `content_files` VALUES (1,'content_1',_binary '','2020-01-10 03:06:55'),(2,'content_2',_binary '','2020-01-10 03:06:55'),(3,'content_3',_binary '','2020-01-10 03:06:55');
/*!40000 ALTER TABLE `content_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscribers`
--

DROP TABLE IF EXISTS `subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscribers` (
  `cellno` varchar(11) NOT NULL,
  `lang` varchar(10) NOT NULL,
  `is_active` bit(1) NOT NULL,
  `sub_dt` datetime NOT NULL,
  PRIMARY KEY (`cellno`),
  UNIQUE KEY `cellno_UNIQUE` (`cellno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscribers`
--

LOCK TABLES `subscribers` WRITE;
/*!40000 ALTER TABLE `subscribers` DISABLE KEYS */;
INSERT INTO `subscribers` VALUES ('03216020287','urdu',_binary '','2020-01-10 11:42:20');
/*!40000 ALTER TABLE `subscribers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-20 19:25:05
