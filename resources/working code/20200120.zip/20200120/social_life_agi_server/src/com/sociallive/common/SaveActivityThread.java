package com.sociallive.common;

import java.sql.Connection;

import org.apache.log4j.Logger;

import com.agiserver.helper.DBHelper;
import com.agiserver.helper.DatabaseException;

public class SaveActivityThread implements Runnable {

	private Connection			conn			= null;
	private String				cellno			= null;
	private String				contextName		= null;
	private String				activityType	= null;
	private String				dtmf			= null;
	private Integer				diff			= null;

	private final static Logger	log				= Logger.getLogger(SaveActivityThread.class);
	private String				query			= "";

	@Override
	public void run() {

		query = "insert into activity(cellno,dt,activity_type,duration,dtmf,context) values(?, now(), ?, ?,?,?)";
		try {
			DBHelper.getInstance().executeDml(
					query,
					conn,
					new Object[] { cellno, activityType, diff, dtmf,
							contextName });
		} catch (DatabaseException e) {
			log.error("DatabaseException", e);
		} catch (Exception e) {
			log.error("Exception", e);
		}
	}

	public SaveActivityThread(Connection conn, String cellno,
			String contextName, String activityType, String dtmf, Integer diff) {
		super();
		this.conn = conn;
		this.cellno = cellno;
		this.contextName = contextName;
		this.activityType = activityType;
		this.dtmf = dtmf;
		this.diff = diff;
	}
}
