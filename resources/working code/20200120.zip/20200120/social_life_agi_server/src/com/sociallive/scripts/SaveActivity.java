package com.sociallive.scripts;

import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.asteriskjava.fastagi.AgiChannel;
import org.asteriskjava.fastagi.AgiException;
import org.asteriskjava.fastagi.AgiRequest;

import com.agiserver.helper.DBConnectionManager;
import com.agiserver.helper.common.AbstractBaseAgiScript;

public class SaveActivity extends AbstractBaseAgiScript
{
	private static final Logger log = Logger.getLogger(SaveActivity.class);

	@Override
	public void service(AgiRequest request, AgiChannel channel) throws AgiException
	{
		String		cellno	= ((channel.getVariable("DB_CLI") == null)? "" : channel.getVariable("DB_CLI"));
		Connection	conn	= null;
		log.info("=========== " + cellno + " start =========" );
		try {			
			String		context		= channel.getVariable("CONTEXT_NAME");
			Integer		maxI		= Integer.parseInt(channel.getVariable("STI"));
			String		uniqueId	= channel.getVariable("UNIQUEID");
						conn		= DBConnectionManager.getInstance().getConnection();
			Statement	statement	= conn.createStatement();
			
			for(Integer i = 1; i < maxI; i++) {
				
				String	activityType	= channel.getVariable("ACTIVITY_TYPE_" + i.toString());
				String	duration		= channel.getVariable("DIFF_" + i.toString());
				String	dtmf			= channel.getVariable("DTMF_ST_" + i.toString());
				String	query			= "INSERT INTO activity"
											+ " (cellno, dt, activity_type, duration, dtmf, context, unique_id) VALUES"
											+ " ('" + cellno + "', NOW(), '" +  activityType + "', '" + duration + "', '" + dtmf + "', '" + context + "', '" + uniqueId + "')";
				
				log.debug(cellno + " : query : " + query);
				statement.addBatch(query);
			}
			statement.executeBatch();
			
		} catch(Exception e) {
			log.error(cellno + " : Exception : ", e);
		} finally {
			try {
				conn.close();
			} 
			catch (Exception e) {
				log.error(cellno + " : SQLException connection cannot be closed ", e);
			}
			log.info("=========== " + cellno + " end =========" );
		}
	}
}
